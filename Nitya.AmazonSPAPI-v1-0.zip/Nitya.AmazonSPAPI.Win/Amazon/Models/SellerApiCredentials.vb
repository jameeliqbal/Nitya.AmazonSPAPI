﻿Namespace Models

    Public Class SellerApiCredentials
        Public Property LWA_App_ClientId As String
        Public Property LWA_App_ClientSecret As String
        Public Property RefreshToken As String
        Public Property AWSKey As String
        Public Property AWSSecret As String
        Public Property RoleARN As String
    End Class

End Namespace