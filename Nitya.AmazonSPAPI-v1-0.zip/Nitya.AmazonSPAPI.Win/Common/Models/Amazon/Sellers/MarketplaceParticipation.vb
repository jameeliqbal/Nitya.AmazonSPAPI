﻿Namespace Common.Models.Amzn.Sellers

    Public Class MarketplaceParticipation
        Public Property marketplace As AmazonMarketPlace
        Public Property participation As SellerParticipation
    End Class

End Namespace