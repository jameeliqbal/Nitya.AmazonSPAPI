﻿Namespace Common.Models.Amzn.Sellers

    Public Class GetMarketplaceParticipationsResponse
        Public Property payload As List(Of MarketplaceParticipation)
        Public Property errors As List(Of ErrorMessage)
    End Class

End Namespace