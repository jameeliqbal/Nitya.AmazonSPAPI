﻿Namespace Common.Models.Amzn.Sellers

    Public Class SellerParticipation
        Public Property isParticipating As Boolean
        Public Property hasSuspendedListings As Boolean
    End Class

End Namespace