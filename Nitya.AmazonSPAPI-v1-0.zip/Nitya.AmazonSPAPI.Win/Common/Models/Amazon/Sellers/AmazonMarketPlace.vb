﻿Namespace Common.Models.Amzn.Sellers

    Public Class AmazonMarketPlace
        Public Property id As String
        Public Property name As String
        Public Property countryCode As String
        Public Property defaultCurrencyCode As String
        Public Property defaultLanguageCode As String
        Public Property domainName As String
    End Class

End Namespace