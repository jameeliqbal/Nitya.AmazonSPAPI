﻿Namespace Common.Models.Amzn.Orders

    Public Class OrderItemsBuyerInfo
        Public Property OrderItems As List(Of OrderItemBuyerInfo)
        Public Property NextToken As String
        Public Property AmazonOrderId As String
    End Class

End Namespace