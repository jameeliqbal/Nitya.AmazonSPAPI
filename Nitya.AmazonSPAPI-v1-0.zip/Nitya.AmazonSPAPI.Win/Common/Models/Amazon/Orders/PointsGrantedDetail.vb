﻿Namespace Common.Models.Amzn.Orders

    Public Class PointsGrantedDetail
        Public Property PointsNumber As Integer
        Public Property PointsMonetaryValue As Money
    End Class

End Namespace