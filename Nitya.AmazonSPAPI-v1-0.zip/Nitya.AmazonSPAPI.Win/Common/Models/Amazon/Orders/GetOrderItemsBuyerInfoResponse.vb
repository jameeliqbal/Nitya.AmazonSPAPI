﻿Namespace Common.Models.Amzn.Orders

    Public Class GetOrderItemsBuyerInfoResponse
        Public Property Payload As List(Of OrderItemsBuyerInfo)
        Public Property Errors As List(Of ErrorMessage)
    End Class

End Namespace