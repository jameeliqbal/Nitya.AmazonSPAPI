﻿Namespace Common.Models.Amzn.Orders

    Public Class FulfillmentInstructions
        Public Property FulfillmentSupplySourceId As String
    End Class

End Namespace