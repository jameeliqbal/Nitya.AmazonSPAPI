﻿Namespace Common.Models.Amzn.Orders

    Public Class ProductInfoDetail
        Public Property NumberOfItems As Integer
    End Class

End Namespace