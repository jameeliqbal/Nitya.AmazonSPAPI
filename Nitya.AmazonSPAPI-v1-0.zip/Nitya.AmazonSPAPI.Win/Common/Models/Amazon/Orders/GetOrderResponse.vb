﻿Namespace Common.Models.Amzn.Orders

    Public Class GetOrderResponse
        Public Property Payload As Order
        Public Property Errors As List(Of ErrorMessage)
    End Class

End Namespace