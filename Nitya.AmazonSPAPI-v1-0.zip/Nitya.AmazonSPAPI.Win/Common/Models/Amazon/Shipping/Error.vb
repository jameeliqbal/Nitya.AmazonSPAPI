﻿
Namespace Common.Models.Amzn.Shipping

    Public Class [Error]
        Public code As String
        Public message As String
        Public details As String
    End Class

End Namespace