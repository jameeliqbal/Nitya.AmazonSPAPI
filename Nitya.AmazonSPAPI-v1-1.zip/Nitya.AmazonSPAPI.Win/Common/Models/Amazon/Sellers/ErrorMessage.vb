﻿Namespace Common.Models.Amzn.Sellers

    Public Class ErrorMessage
        Public code As String
        Public message As String
        Public details As String
    End Class

End Namespace