﻿Namespace Common.Models.Amzn.Shipping
    Public Class [Event]
        Public Property EventCode As String
        Public Property EventTime As String
        Public Property Location As Location

    End Class
End Namespace