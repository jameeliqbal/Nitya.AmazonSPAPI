﻿Namespace Common.Models.Amzn.Shipping
    Public Class Location
        Public Property StateOrRegion As String
        Public Property City As String
        Public Property CountryCode As String
        Public Property PostalCode As String

    End Class
End Namespace