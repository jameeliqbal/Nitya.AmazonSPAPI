﻿Namespace Common.Models.Amzn.Shipping
    Public Class GetTrackingInformationResponse
        Public Property Payload As TrackingInformation
        Public Property Errors As [Error]()
    End Class
End Namespace
