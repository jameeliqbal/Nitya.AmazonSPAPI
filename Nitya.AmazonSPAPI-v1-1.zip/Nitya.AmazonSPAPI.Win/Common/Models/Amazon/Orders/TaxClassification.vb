﻿Namespace Common.Models.Amzn.Orders

    Public Class TaxClassification
        Public Property Name As String
        Public Property Value As String
    End Class

End Namespace