﻿Namespace Common.Models.Amzn.Orders

    Public Class GetOrderBuyerInfoResponse
        Public Property Payload As OrderBuyerInfo
        Public Property Errors As List(Of ErrorMessage)
    End Class

End Namespace