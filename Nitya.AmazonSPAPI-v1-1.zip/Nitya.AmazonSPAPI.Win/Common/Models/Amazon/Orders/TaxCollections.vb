﻿Namespace Common.Models.Amzn.Orders

    Public Class TaxCollections
        Public Property Model As String
        Public Property ResponsibleParty As String
    End Class

End Namespace