﻿Namespace Common.Models.Amzn.Orders

    Public Class GetOrdersResponse
        Public Property Payload As OrdersList
        Public Property Errors As List(Of ErrorMessage)
    End Class

End Namespace