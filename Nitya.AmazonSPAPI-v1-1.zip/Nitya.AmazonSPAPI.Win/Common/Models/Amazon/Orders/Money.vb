﻿Namespace Common.Models.Amzn.Orders

    Public Class Money
        Public Property CurrencyCode As String
        Public Property Amount As String
    End Class

End Namespace