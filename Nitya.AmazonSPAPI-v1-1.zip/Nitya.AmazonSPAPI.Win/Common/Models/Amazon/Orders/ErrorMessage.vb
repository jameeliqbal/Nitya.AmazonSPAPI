﻿Namespace Common.Models.Amzn.Orders

    Public Class ErrorMessage
        Public code As String
        Public message As String
        Public details As String
    End Class

End Namespace