﻿Namespace Common.Models.Amzn.Orders

    Public Class BuyerCustomizedInfoDetail
        Public Property CustomizedURL As String
    End Class

End Namespace