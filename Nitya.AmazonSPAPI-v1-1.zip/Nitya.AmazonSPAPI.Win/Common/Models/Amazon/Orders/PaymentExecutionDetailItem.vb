﻿Namespace Common.Models.Amzn.Orders

    Public Class PaymentExecutionDetailItem
        Public Property Payment As Money
        Public Property PaymentMethod As String
    End Class

End Namespace