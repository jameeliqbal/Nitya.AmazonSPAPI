﻿Namespace Common.Models.Amzn.Orders

    Public Class GetOrderAddressResponse
        Public Property Payload As OrderAddress
        Public Property Errors As List(Of ErrorMessage)
    End Class

End Namespace