﻿Namespace Common.Models.Amzn.Orders

    Public Class OrderAddress
        Public Property AmazonOrderId As String
        Public Property ShippingAddress As Address = New Address()
    End Class

End Namespace