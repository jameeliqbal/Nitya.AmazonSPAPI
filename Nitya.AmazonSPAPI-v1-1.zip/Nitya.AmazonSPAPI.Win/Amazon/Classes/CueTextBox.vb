﻿Imports System
Imports System.Runtime.InteropServices
Imports System.Windows.Forms

Public Class CueTextBox
    Inherits TextBox

    Private Const EM_SETCUEBANNER As Integer = &H1501
    <DllImport("user32.dll", CharSet:=CharSet.Auto)>
    Private Shared Function SendMessage(ByVal hWnd As IntPtr, ByVal msg As Integer,
        ByVal wParam As Integer, ByVal lParam As String) As Int32
    End Function

    Protected Overrides Sub OnHandleCreated(e As EventArgs)
        MyBase.OnHandleCreated(e)
        If Not String.IsNullOrEmpty(CueBanner) Then UpdateCueBanner()
    End Sub

    Private m_CueBanner As String
    Public Property CueBanner As String
        Get
            Return m_CueBanner
        End Get
        Set(ByVal value As String)
            m_CueBanner = value
            UpdateCueBanner()
        End Set
    End Property

    Private Sub UpdateCueBanner()
        SendMessage(Me.Handle, EM_SETCUEBANNER, 0, CueBanner)
    End Sub
End Class